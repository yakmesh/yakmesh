// Yakmesh Unified Node Configuration
// ----------------------------------------------------------
// ALL known peers are listed in `bootstrap`.
// Each node self-skips its own address at startup, so this
// file can (and MUST) be byte-identical on every deployment.
// The Validation Oracle hashes all .js files — identical
// source guarantees identical network-id across the mesh.
// ----------------------------------------------------------
export default {
  node: {
    name: 'Yakmesh Node',
    region: 'auto',
  },
  network: {
    httpPort: 3080,
    wsPort: 9080,
  },
  bootstrap: [
    'ws://156.67.75.34:9080',   // Hostinger VPS
    'ws://192.168.1.178:9080',  // LAN server (WIN-LQH9ULSNBFU)
    'ws://192.168.1.172:9080',  // Local dev machine
  ],
  sherpa: {
    enabled: true,
    // Seeds: HTTPS endpoints to crawl for peer discovery (port 443, always open)
    seeds: ['https://yakmesh.dev'],
    // Node-specific: set via env vars so config file stays byte-identical
    // YAKMESH_SELF_ENDPOINT=https://yakmesh.dev (only on Hostinger)
    // YAKMESH_WS_ENDPOINT=wss://yakmesh.dev/mesh/ws (only if WSS available)
    selfEndpoint: process.env.YAKMESH_SELF_ENDPOINT || null,
    wsEndpoint: process.env.YAKMESH_WS_ENDPOINT || null,
    // HTTP relay endpoint for nodes behind firewalls
    relayEndpoint: process.env.YAKMESH_RELAY_ENDPOINT || null,
  },
  database: {
    path: './data/yakmesh.db',
    replication: { enabled: true, syncInterval: 5000 },
  },
  oracle: { timeSource: 'auto', phaseWindow: 30000 },
  annex: { enabled: true },
  sakshi: { dimensions: ['CONNECTION_CHURN', 'MESSAGE_RATE'] },
  karma: { initialTrust: 0.5 },
  darshan: { maxBandwidth: 10 * 1024 * 1024 },
};
